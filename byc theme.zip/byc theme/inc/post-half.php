<?php /* Posts loop - half column */ ?>

<div class="large-6 columns">
	<a href="<?php the_permalink(); ?>" class="poster">
		<div class="image" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>></div>
		<div class="info">
			<div class="inner">
				<div class="categories"><?php $category = get_the_category(); echo $category[0]->cat_name;?></div>
				<h2 class="thumb-title"><?php the_title(); ?></h2>
			</div>
		</div>
	</a>
</div>

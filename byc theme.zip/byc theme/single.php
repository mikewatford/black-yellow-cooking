<?php get_header(); ?>

	<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>

		<div class="cover" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>>
			<div class="tint">
				<div class="row">
					<div class="small-6 small-centered large-6 large-centered columns title-position">
						<h1 class="page-title"><?php the_title(); ?></h1>
					</div>
				</div>
				<div class="row">
					<div class="large-4 large-push-2 columns">
						<a id="myBtn"><p class="post-details">By <?php the_author(); ?></p></a>
							<div id="myModal" class="modal">
								<div class="modal-content">
									<div class="row">
										<div class="large-6 large-centered">
											<div class="author-portrait">
												<?php echo get_avatar( get_the_author_meta( 'ID' ), 150 ); ?>
											</div>
												<p class="author-bio">
													<?php $authorDesc = the_author_meta('description'); echo $authorDesc; ?>
												</p>
												<div class="bio-position"><a class="author-bio" href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>">More articles by <?php the_author(); ?></a></div>
												<span class="close">&otimes;</span>
										</div>
									</div>
								</div>
							</div>
					</div>

					<div class="large-4 columns">
						<p class="post-details"><?php the_time( 'F jS Y' ); ?></p>
					</div>

					<div class="large-4 large-pull-2 columns">
						<p class="post-details"><?php the_category(', '); ?></p>
					</div>

				</div>

			</div>
		</div>

		<main>
			<?php the_content(' '); ?>
		</main>

	<?php endwhile; ?>
	<?php else : ?>

	<?php get_template_part( 'inc/post-none' ); ?>

	<?php endif; ?>

		<div class="row expanded">
			<div class="large-12">

			<?php
				$previous = get_previous_post();
				$next = get_next_post();
			?>

				<?php if ($previous != NULL) { ?>

				<a href="<?php echo get_permalink($previous->ID); ?>">
					<div class="large-6 columns next-previous" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($previous->ID) ); echo 'style="background-image: url('. $url.');">' ?>
						<div class="shade"></div>
							<div class="hover">
								<div class="previous">Previous Post</div>
								<div class="previous-router-title"><?php echo esc_attr($previous->post_title); ?></div>
							</div>
					</div>
				</a>

				<?php } else { ?>

				<div class="large-6 columns next-previous empty-post">
				<div class="shade"></div>
					<div class="hover">
						<div class="previous">It Begins</div>
						<div class="previous-router-title">Starts with step one</div>
					</div>
				</div>

				<?php } ?>

				<?php if ($next != NULL) { ?>

				<a href="<?php echo get_permalink($next->ID); ?>">
					<div class="large-6 columns next-previous" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($next->ID) ); echo 'style="background-image: url('. $url.');">' ?>
					<div class="shade"></div>
						<div class="hover">
							<div class="next">Next Post</div>
							<div class="next-router-title"><?php echo esc_attr($next->post_title); ?></div>
						</div>
					</div>
				</a>

				<?php } else { ?>

				<div class="large-6 columns next-previous empty-post">
				<div class="shade"></div>
					<div class="hover">
						<div class="next">Keep it locked</div>
						<div class="next-router-title">The next post is coming up</div>
					</div>
				</div>

				<?php } ?>

			</div>
		</div>

<?php get_footer(); ?>
<?php
/*
Template Name: Journal
*/
?>

<?php get_header(); ?>

		<div class="empty-post cover nav-top-margin">
			<div class="tint">
				<div class="row">
					<div class="small-12 large-6 large-centered columns title-position">
						<h1 class="page-title">Journal</h1>
						<p class="page-intro">Explore our eating adventures</p>
					</div>
					</div>
				</div>
			</div>
		</div>

	<div class="row expanded no-padding">
	<?php $wpb_all_query = new WP_Query(array('post_type'=>'post', 'post_status'=>'publish', 'posts_per_page'=>-1)); ?>
	<?php if ( $wpb_all_query->have_posts() ) : ?>

	<?php while ( $wpb_all_query->have_posts() ) : $wpb_all_query->the_post(); ?>

		<div class="large-12">
			<a href="<?php the_permalink(); ?>" class="poster">
			<div class="image" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>></div>
				<div class="info">
					<div class="inner">
						<div class="categories"><?php $category = get_the_category(); echo $category[0]->cat_name;?></div>
						<h2 class="thumb-title"><?php the_title(); ?></h2>
					</div>
				</div>
			</a>
		</div>

	</div>

	<?php endwhile; ?>

	<?php wp_reset_postdata(); ?>

	<?php else : ?>

	<?php get_template_part( 'inc/posts-none' ); ?>

	<?php endif; ?>

<?php get_footer(); ?>
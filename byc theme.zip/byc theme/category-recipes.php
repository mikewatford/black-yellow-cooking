<?php
/*
Template Name: Category Recipes
*/
?>

<?php get_header(); ?>

		<div class="recipes-poster cover nav-top-margin">
			<div class="tint">
				<div class="row">
					<div class="small-12 large-6 large-centered columns title-position">
						<?php if ( have_posts() ) : ?>
						<h1 class="page-title">Recipes</h1>
						<p class="page-intro">Eat our food, it's dope</p>
					</div>
					</div>
				</div>
			</div>
		</div>

	<div class="row expanded no-padding">
	<?php while ( have_posts() ) : the_post(); ?>
		<div class="large-12">
			<a href="<?php the_permalink(); ?>" class="poster">
			<div class="image" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>></div>
				<div class="info">
					<div class="inner">
						<div class="categories"><?php $category = get_the_category(); echo $category[0]->cat_name;?></div>
						<h2 class="thumb-title"><?php the_title(); ?></h2>
					</div>
				</div>
			</a>
		</div>

	</div>

	<?php endwhile; ?>

	<?php else : ?>

	<?php get_template_part( 'inc/posts-none' ); ?>

	<?php endif; ?>

<?php get_footer(); ?>
<!doctype html>
<html <?php language_attributes(); ?> class="no-js" lang="en">
  <head>
	<meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge,chrome=1">
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Black and Yellow cooking is the food adventure of culture exhange" />
	<meta property="og:title" content="Black and Yellow Cooking" />
	<meta property="og:description" content="Black and Yellow cooking is the food adventure of culture exhange" />
	<meta property="og:image" content="https://blackandyellow.cooking/og.png" />
    <title><?php wp_title(''); ?><?php if(wp_title(' ', false)) { echo ' | '; } ?><?php bloginfo('name'); ?></title>
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" />
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/styles/previous/foundation.min.css" />
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/styles/main.css" />
    <link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/favicon.ico" type="image/x-icon"/>
     <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <?php wp_head(); ?>
  </head>
  <body>

	<header class="site-nav">
<!-- 		Small Navigation -->
		<div class="title-bar" data-responsive-toggle="nav-menu" data-hide-for="medium">
		  <a class="logo-small show-for-small-only" href="/home"><img src="<?php bloginfo('template_url'); ?>/images/small-logo.png" /></a>
		  <button class="menu-icon" type="button" data-toggle></button>
		</div>

<!-- 		Medium-Up Navigation -->
		<nav class="top-bar" id="nav-menu">

			<div class="logo-wrapper hide-for-small-only">
				<div class="logo">
					<a href="/home"><img src="<?php bloginfo('template_url'); ?>/images/logo.png"></a>
				</div>
			</div>

<!-- 		Left Nav Section -->
			<div class="top-bar-left nav">
				<ul class="vertical medium-horizontal menu">
					<li><a href="/journal">Journal</a></li>
					<li><a href="/category/recipes">Recipes</a></li>
				    <li><a href="/wanderlust">Wanderlust</a></li>
				</ul>
			</div>

<!-- 		Right Nav Section -->
		<div class="top-bar-right nav">
			<ul class="vertical medium-horizontal menu">
				<li><a href="/about">About</a></li>
				<li><a href="https://www.instagram.com/blackandyellowcooking/">Instagram</a></li>
				<li><a href="https://twitter.com/B_and_Y_Cooking/">Twitter</a></li>
			</ul>
		</div>

		</nav>
	</header>
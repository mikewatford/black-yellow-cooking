		<footer>
			<div class="row">
				<div class="col large-centered social">
						<a href="https://www.instagram.com/blackandyellowcooking/">
							<img src="<?php bloginfo('template_url'); ?>/images/insta.png">
						</a>
						<a href="https://twitter.com/B_and_Y_Cooking">
							<img src="<?php bloginfo('template_url'); ?>/images/twitter.png">
						</a>
						<div class="copyright">&copy; Black &amp; Yellow Cooking <?php echo date('Y'); ?></div>
				</div>
			</div>
		</footer>

		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/scripts/foundation.min.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/scripts/what-input.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/scripts/modal.js"></script>
    <script>jQuery(document).foundation();</script>
	<?php wp_footer(); ?>
  </body>
</html>
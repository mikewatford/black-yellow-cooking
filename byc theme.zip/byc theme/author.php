<?php get_header(); ?>

		<div class="empty-post cover nav-top-margin">
			<div class="tint">
				<div class="row">
					<div class="large-6 large-centered">
						<div class="author-portrait">
							<?php echo get_avatar( get_the_author_meta( 'ID' ), 150 ); ?>
						</div>
						<div class="bio-position categories"><?php the_author(); ?></div>
						<p class="author-page-bio">
							<?php $authorDesc = the_author_meta('description'); echo $authorDesc; ?>
						</p>
					</div>
				</div>
			</div>
		</div>

	<div class="row expanded no-padding">

		<div class="large-12">
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<a href="<?php the_permalink(); ?>" class="poster">
			<div class="image" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>></div>
				<div class="info">
					<div class="inner">
						<div class="categories"><?php $category = get_the_category(); echo $category[0]->cat_name;?></div>
						<h2 class="thumb-title"><?php the_title(); ?></h2>
					</div>
				</div>
			</a>
		</div>

	</div>

	<?php endwhile; ?>
	<?php else : ?>

	<?php get_template_part( 'inc/posts-none' ); ?>

	<?php endif; ?>

<?php get_footer(); ?>
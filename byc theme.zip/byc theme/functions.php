<?php
function wpb_remove_version() {

return '';

}
add_filter('the_generator', 'wpb_remove_version');

add_theme_support( 'post-thumbnails' );

remove_filter( 'authenticate', 'wp_authenticate_email_password', 20 );

function no_wordpress_errors(){
  return 'Something is wrong!';
}
add_filter( 'login_errors', 'no_wordpress_errors' );


/*********************
Custom log in
*********************/
function custom_login() {
	$files = '<link rel="stylesheet" href="'.get_bloginfo('template_directory').'/styles/login.css" />';
	echo $files;
}
add_action('login_head', 'custom_login');

/*********************
LOADS MODAL FOR POSTS
*********************/

/*
// Call the function
function enqueue_files() {

  // Specify the conditional tag
  if ( is_single() ) {

    // If page matches, then load the following files
   wp_enqueue_script('jquery.min.js', get_template_directory_uri().'/scripts/jquery.min.js', array('jquery'));
   wp_enqueue_script('what-input.min.js', get_template_directory_uri().'/scripts/vendor/what-input.min.js', array('jquery'));
   wp_enqueue_script('foundation.min.js', get_template_directory_uri().'/scripts/foundation.min.js', array('jquery'));
   wp_enqueue_script('modal.js', get_template_directory_uri().'/scripts/modal.js');

   // If the condition tag does not match...
   } else {

   // ...then load the global files instead
   wp_enqueue_script('jquery.min.js', get_template_directory_uri().'/scripts/jquery.min.js', array('jquery'));
   wp_enqueue_script('what-input.min.js', get_template_directory_uri().'/scripts/vendor/what-input.min.js', array('jquery'));
   wp_enqueue_script('foundation.min.js', get_template_directory_uri().'/scripts/foundation.min.js', array('jquery'));
  }
}

// Hook into the WordPress Function
add_action( 'wp_enqueue_scripts', 'enqueue_files' );
*/

/*********************
REMOVE QUERY STRING FROM URL
*********************/

function _remove_script_version( $src ){
$parts = explode( '?', $src );
return $parts[0];
}
add_filter( 'script_loader_src', '_remove_script_version', 15, 1 );
add_filter( 'style_loader_src', '_remove_script_version', 15, 1 );

/*********************
GET POST LAYOUT
*********************/
if ( ! function_exists( 'byc_post_layout' ) ) {
    function byc_post_layout() {

	    $byc_post_layout = '1';
        global $wp_query;

		switch ( $byc_post_layout ) {
            case '2':
                if ( ( $wp_query->current_post ) == 0 ) {
                    get_template_part( 'inc/post-full' );
                } else {
                    get_template_part( 'inc/post-half' );
                }
                break;
            case '3':
                get_template_part( 'inc/post-full' );
                break;

        default:
                if ( ( $wp_query->current_post + 1 ) % 3 != 1 ) {
                    get_template_part( 'inc/post-half' );
                } else {
                    get_template_part( 'inc/post-full' );
                }
                break;
        }
    }
}


?>
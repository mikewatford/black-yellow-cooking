<?php get_header(); ?>

		<div class="home-hero cover nav-top-margin">
			<div class="tint">
				<div class="row">
					<div class="medium-12 large-4 large-centered columns hero-logo">
						<img src="<?php bloginfo('template_url'); ?>/images/crest_logo.png">
					</div>
				</div>
			</div>
		</div><!-- end home header bg -->

	<!-- post articles -->
	<div class="row expanded no-padding">

	<?php if ( have_posts() ) : ?>

	<h2>Search results for <?php the_search_query(); ?></h2>

	<?php while (have_posts()) : the_post(); ?>

		<div class="large-12">
			<a href="<?php the_permalink(); ?>" class="poster">
			<div class="image" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>></div>
				<div class="info">
					<div class="inner">
						<div class="categories"><?php $category = get_the_category(); echo $category[0]->cat_name;?></div>
						<h2 class="thumb-title"><?php the_title(); ?></h2>
					</div>
				</div>
			</a>
		</div>

	</div>
	<!-- post articles -->

	<?php endwhile; ?>
	<?php else : ?>

	<?php get_template_part( 'inc/posts-none' ); ?>

	<?php endif; ?>

<?php get_footer(); ?>
<?php
/*
Template Name: Wanderlust
*/
?>

<?php get_header(); ?>

		<div class="wanderlust-hero cover">
			<div class="tint">
				<div class="row">
					<div class="small-12 large-6 large-centered columns title-position">
						<h1 class="page-title">Wanderlust</h1>
						<p class="page-intro">We travel, some of us forever, to seek other states, other lives, other souls</p>
					</div>
				</div>
			</div>
		</div>

	<!-- vegas post  -->
		  	<div class="travel-poster vegas-hero">
				<div class="column row">
					<div class="large-12 columns">
						<div class="row">
							<div class="large-4 columns categories cat-align">
								<a href="/category/vegas">Vegas</a>
							</div>
						</div>
						<div class="row">
							<div class="large-12 columns">
								<div class="large-7 columns post-title">Las Vegas, NV</div>
								<div class="small-7 small-pull-2 medium-3 medium-pull-4 large-3 large-pull-2 columns white-btn">
									<a href="/category/vegas">View Posts</a>
								</div>
							</div>
						</div>
					</div>
				</div>
		  	</div>
	<!-- vegas post  -->

<?php get_footer(); ?>
<?php
/*
Template Name: Home
*/
?>

<?php get_header(); ?>

		<div class="home-hero cover nav-top-margin">
			<div class="tint">
				<div class="row">
					<div class="medium-12 large-4 large-centered columns hero-logo">
						<img src="<?php bloginfo('template_url'); ?>/images/crest_logo.png">
					</div>
					<div class="large-6 large-centered">
						<h1 class="header-title">The cultural exchange of <br>flavor confusion</h1>
					</div>
				</div>
			</div>
		</div>

	<div class="row expanded no-padding">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

		<div class="large-12">
			<a href="<?php the_permalink(); ?>" class="poster">
			<div class="image" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>></div>
				<div class="info">
					<div class="inner">
						<div class="categories"><?php $category = get_the_category(); echo $category[0]->cat_name;?></div>
						<h2 class="thumb-title"><?php the_title(); ?></h2>
					</div>
				</div>
			</a>
		</div>

	</div>

	<?php endwhile; ?>
	<?php else : ?>

	<?php get_template_part( 'inc/post-none' ); ?>

	<?php endif; ?>

		<div class="row">
			<div class="small-8 small-offset-1 small-centered  medium-3 large-3 more-posts">
				<div class="black-btn">
					<a href="/journal">more posts</a>
				</div>
			</div>
		</div>

<?php get_footer(); ?>